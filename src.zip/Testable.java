/*
	Testable.java
	
	This class is provided for auto-testing purpose. Do NOT change it. 
	
	Coded by: Jin Huang
	Modified by: Jianzhong Qi, 29/04/2015
*/

public interface Testable {
	public String advancedMove(boolean[] available, String lastMove);
}
