/**
 * Created by 45377 on 2017/5/8.
 */
public class InvalidMoveException extends Exception{
    private int displayNumber;
    public InvalidMoveException(){
        super("InvalidMoveException");
    }
    public InvalidMoveException(String message){
        super(message);
    }
    // overload
    public InvalidMoveException(int moveNumber){
        super("InvalidMoveException");
        displayNumber = moveNumber;
    }
    public int getDisplayNumber(){
        return displayNumber;
    }
}
